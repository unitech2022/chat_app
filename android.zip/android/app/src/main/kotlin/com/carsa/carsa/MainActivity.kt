package com.carsa.carsa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
